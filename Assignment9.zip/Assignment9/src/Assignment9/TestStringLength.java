package Assignment9;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.RepeatedTest;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInfo;
import static org.junit.Assert.*;
public class TestStringLength {
	
	StringLength obj;
	@BeforeEach
	public void initialize(TestInfo testInfo) {
		System.out.println("Start..." + testInfo.getDisplayName());
		obj=new StringLength();
	}
	@AfterEach
	public void testfinish(TestInfo testInfo) {
		System.out.println("Finished..." + testInfo.getDisplayName());
		System.out.println();
	}

	// a subdivision
	@DisplayName("Testing check with good path")
	@Test
	public void test_lengthOfString() {
		String word  = "Ajai";
		int expected = 4;
		int actual=obj.getStringLength(word);
		assertEquals(actual,expected);
		System.out.println("Length of string is: "+ actual);
		
	}
	
	//b subdivision
	@DisplayName("testing check with exceptions")
	@Test
	public void testCheck_WhenNullValuePassed() {
		String word=null;
		String expected="String is Null";
	Exception actualResult = assertThrows(NullPointerException.class,()-> {
			obj.getStringLength(word);
		});
		assertEquals(actualResult.getMessage(), expected);
		System.out.println("Length of string is: "+ actualResult.getMessage());
		}
	
	@DisplayName("testing with parameterized test")
	@ParameterizedTest
	@CsvSource({
		"Amdocs,6",
		"company,7"
	})
	public void testCheck_WhenNullValuePassed_ShouldThrowException(String word, int expectedlength){
		int actuallength=obj.getStringLength(word);
		assertEquals(actuallength, expectedlength);
		System.out.println("Length of string is: "+ actuallength);
	}
	
	
	//d sub division
    @Nested
    @DisplayName("Tests for nested test")
    class NestedTestClass {
 
    	@BeforeEach
    	public void initialize(TestInfo testInfo) {
    		System.out.println("Start..." + testInfo.getDisplayName());
    		obj=new StringLength();
    	}
    	@AfterEach
    	public void testfinish(TestInfo testInfo) {
    		System.out.println("Finished..." + testInfo.getDisplayName());
    		System.out.println();
    	}
 
        @DisplayName("testing with Nested test")
        @Test
    	public void NestedTest_lengthOfString() {
    		String word  = "KUMAR";
    		int expected = 5;
    		int actual=obj.getStringLength(word);
    		assertEquals(actual,expected);
    		System.out.println("Length of string is: "+ actual);
    		
    	}
    }
	
	//e subdivision
	@DisplayName("Repeated Test")
	@RepeatedTest(value = 5, name="{displayName}. Repetition {currentRepetition} of " + "{totalRepetitions}")
	public void repeatedTestCheck() {
		String word  = "Repeated test";
		int expected = 13;
		int actual=obj.getStringLength(word);
		assertEquals(actual, expected);
		System.out.println("Length of string is: "+ actual);
		
	}
	@Disabled
	@DisplayName("Testing check with good path")
	@Test
	public void disableTest_lengthOfString() {
		String word  = "Ajai";
		int expected = 4;
		int actual=obj.getStringLength(word);
		assertEquals(actual,expected);
		
	}

}
