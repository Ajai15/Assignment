package Assignment9;
import java.util.Scanner;
public class StringLength {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter the String: ");
		String str=sc.nextLine();
		StringLength lenobj= new StringLength();
		int length=lenobj.getStringLength(str);
		
		System.out.println("Length of the String "+str+" is: "+length);
		

	}
	
	public int getStringLength(String str) {
		if(str==null)
			throw new NullPointerException("String is Null");
			
		return str.length();
			
	}

}
