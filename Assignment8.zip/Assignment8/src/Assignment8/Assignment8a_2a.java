package Assignment8;

class Sync{
    static int n;
    public void print(int n){
        synchronized(this){
            for (int i = 1; i < 6; i++) {
                System.out.println(i*n+" "+Thread.currentThread().getName());
                 try {
                     Thread.sleep(100);
                 } catch (Exception e) {
                     System.out.println(e);
                 }
            }
        }
    }
}

class Thread1 extends Thread{
	Sync s;
	int n=5;
	public Thread1(Sync s) {
		this.s=s;
	}
	
	public void run() {
		s.print(n);
	}

}

class Thread2 extends Thread{
	Sync s;
	int n=100;
	public Thread2(Sync s) {
		this.s=s;
	}
	
	public void run() {
		s.print(n);
	}

}
public class Assignment8a_2a {
    public static void main(String[] args) {
        Sync obj=new Sync();
        Thread1 t1=new Thread1(obj);
        Thread2 t2=new Thread2(obj);
        t1.start();
        t2.start();
    }
}
