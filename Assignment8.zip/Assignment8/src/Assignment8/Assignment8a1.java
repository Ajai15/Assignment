package Assignment8;

import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.RecursiveAction;
import java.util.*;

class task extends RecursiveAction{

    private List<employee> employees;

    private int first;
    private int last;

    
    public task(List<employee> employees, int first, int last) {
        this.employees = employees;
        this.first = first;
        this.last = last;
    }

    @Override
    protected void compute() {
        
        if(last-first<15){
            updateSalary();
        }
        else{
            int mid = (first+last)/2;
            task t1 =new task(employees, first, mid);
            task t2 = new task(employees, mid+1, last);
            invokeAll(t1,t2);
            System.out.println(Thread.currentThread());
        }
        return;
    }

    private void updateSalary() {
        for (int i = first; i < last; i++) {
            employee e = employees.get(i);
            e.setSalary(e.getSalary()*100);
        }
    }
}

class employee{
    private String empName;
    private double salary;

    public void setEmpName(String empName) {
        this.empName = empName;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    public String getEmpName() {
        return empName;
    }
    
    public double getSalary(){
        return salary;
    }
}

class empGen{

    public List<employee> generator(int size){
        List<employee> lst =new ArrayList<>();
        for(int i=1;i<size;i++){
            employee e =new employee();
            e.setEmpName("Emp"+ i);
            e.setSalary(i*1000);
            lst.add(e);
        }
        return lst;
    }
}
public class Assignment8a1 {
    public static void main(String[] args) {
    	Scanner sc=new Scanner(System.in);
    	System.out.println("Enter the number of employee: ");
    	int size=sc.nextInt();
    	List<employee> list =new ArrayList<>();
        for(int i=1;i<size;i++){
            employee e =new employee();
            e.setEmpName("Emp"+ i);
            e.setSalary(i*1000);
            list.add(e);
        }
        task t =new task(list,0,list.size());
        try (ForkJoinPool pool = ForkJoinPool.commonPool()) {
            pool.execute(t);

            System.out.println("Steal Count: "+pool.getStealCount());
            System.out.println("Parallelsim: "+pool.getParallelism());
            System.out.println("Active Threads: "+pool.getActiveThreadCount());
            System.out.println("Running Thread count: "+pool.getRunningThreadCount());
            System.out.println(""+ForkJoinPool.commonPool());
        }
    }
}
