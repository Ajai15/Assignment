package Assignment8;
import java.lang.Thread;
class ThreadA extends Thread{
    @Override
    public void run(){
        System.out.println("Thread is running using thread class...");

    }
}
class ThreadB implements Runnable{
    @Override
    public void run(){
        System.out.println("Thread is running using Runnable interface...");
    }
}
public class Assignment8b1{
    public static void main(String []args) {
    	ThreadA t1 = new ThreadA();
    	ThreadA t2 = new ThreadA();
    	ThreadA t3 = new ThreadA();
        t1.start();
        t2.start();
        t3.start();
        System.out.println(t1.getName()+" "+t1.threadId()+" "+t1.getPriority()+" "+t1.isAlive());
        System.out.println(t2.getName()+" "+t2.threadId()+" "+t2.getPriority()+" "+t2.isAlive());
        System.out.println(t3.getName()+" "+t3.threadId()+" "+t3.getPriority()+" "+t3.isAlive());
        
        
        ThreadB r1=new ThreadB();
        Thread tr1=new Thread(r1);
        ThreadB r2=new ThreadB();
        Thread tr2=new Thread(r2);
        ThreadB r3=new ThreadB();
        Thread tr3=new Thread(r3);
        tr1.start();
        tr2.start();
        tr3.start();
        System.out.println(tr1.getName()+" "+tr1.threadId()+" "+tr1.getPriority()+" "+tr1.isAlive());
        System.out.println(tr2.getName()+" "+tr2.threadId()+" "+tr2.getPriority()+" "+tr2.isAlive());
        System.out.println(tr3.getName()+" "+tr3.threadId()+" "+tr3.getPriority()+" "+tr3.isAlive());   
    }
}
