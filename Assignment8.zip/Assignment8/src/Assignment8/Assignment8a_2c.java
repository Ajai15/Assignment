package Assignment8;

import java.util.concurrent.atomic.AtomicInteger;

class progWithAtomic extends Thread{

    private static AtomicInteger i = new AtomicInteger(5);
    private static AtomicInteger j = new AtomicInteger(10);
    @Override

    public void run(){
        System.out.println("i incremented value "+ i.incrementAndGet());
        System.out.println("j decremented value "+ j.decrementAndGet());
        System.out.println("I value : "+i.get()+" "+ Thread.currentThread().getName());
        System.out.println("compare and set  "+i.compareAndSet(7, 6));
        System.out.println("J value : "+j.get()+" "+Thread.currentThread().getName());
    }
}

public class Assignment8a_2c {
    public static void main(String[] args) {
        progWithAtomic p1 =new progWithAtomic();
        progWithAtomic p2 =new progWithAtomic();
        p1.start();
        p2.start();
    }
}

