package Assignment8;

class ThreadClass1 extends Thread {
	public void run() {
		for(int i=101;i<201;i++) {
			System.out.println(i);
		}
	}
}
class ThreadClass2 extends Thread {
	public void run() {
		for(int i=201;i<301;i++) {
			System.out.println(i);
		}
	}
}
class ThreadClass3 extends Thread {
	public void run() {
		for(int i=301;i<401;i++) {
			System.out.println(i);
		}
	}
}

public class Assignment8b2{
    public static void main(String [] args){
        ThreadClass1 t1= new ThreadClass1();
        ThreadClass2 t2= new ThreadClass2();
        ThreadClass3 t3= new ThreadClass3();
        t1.start();
        t2.start();
        t3.start();
    }
}
